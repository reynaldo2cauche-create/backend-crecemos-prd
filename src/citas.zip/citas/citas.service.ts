import { Injectable, BadRequestException, NotFoundException, Inject, forwardRef } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Cita } from './entities/cita.entity';
import { CitaReunionClinica } from './entities/cita-reunion-clinica.entity';
import { CitaReunionClinicaTerapeutas } from './entities/cita-reunion-clinica-terapeutas.entity';
import { CitaReunionClinicaServicios } from './entities/cita-reunion-clinica-servicios.entity';
import { CitaVisitaEscolar } from './entities/cita-visita-escolar.entity';
import { MotivoCita } from './entities/motivo-cita.entity';
import { EstadoCita } from './entities/estado-cita.entity';
import { TipoCita } from './entities/tipo-cita.entity';
import { CrearCitaDto } from './dto/crear-cita.dto';
import { HistorialCitasService } from './historial-citas.service';
import { NotificacionesService } from '../notificaciones/notificaciones.service';
import { CompraService } from '../sorteos/compra.service';

@Injectable()
export class CitasService {
  constructor(
    @InjectRepository(Cita)
    private citaRepo: Repository<Cita>,
    @InjectRepository(CitaReunionClinica)
    private reunionRepo: Repository<CitaReunionClinica>,
    @InjectRepository(CitaReunionClinicaTerapeutas)
    private reunionTerapeutasRepo: Repository<CitaReunionClinicaTerapeutas>,
    @InjectRepository(CitaReunionClinicaServicios)
    private reunionServiciosRepo: Repository<CitaReunionClinicaServicios>,
    @InjectRepository(CitaVisitaEscolar)
    private visitaEscolarRepo: Repository<CitaVisitaEscolar>,
    @InjectRepository(MotivoCita)
    private motivoRepo: Repository<MotivoCita>,
    @InjectRepository(EstadoCita)
    private estadoRepo: Repository<EstadoCita>,
    @InjectRepository(TipoCita)
    private tipoRepo: Repository<TipoCita>,
    @Inject(forwardRef(() => HistorialCitasService))
    private historialService: HistorialCitasService,
    @Inject(forwardRef(() => NotificacionesService))
    private notificacionesService: NotificacionesService,
    @Inject(forwardRef(() => CompraService))
    private compraService: CompraService,
  ) {}

  private async determinarTipoCita(motivo_id: number): Promise<string> {
    const motivo = await this.motivoRepo.findOne({
      where: { id: motivo_id },
      relations: ['tipoCita'],
    });

    if (!motivo || !motivo.tipoCita) {
      throw new BadRequestException('Motivo de cita no válido');
    }

    return motivo.tipoCita.codigo;
  }

  /**
   * Verifica que el paciente no tenga una cita que se solape en el mismo horario.
   * Lanza BadRequestException si existe conflicto.
   */
  private async verificarConflictoPaciente(
    paciente_id: number,
    fecha: string,
    hora_inicio: string,
    hora_fin: string,
    excludeCitaId?: number,
  ): Promise<void> {
    // Convierte "HH:mm" o "HH:mm:ss" a minutos totales
    const toMinutes = (time: string): number => {
      if (!time) return 0;
      const partes = time.split(':').map(Number);
      return partes[0] * 60 + (partes[1] || 0);
    };

    const nuevaInicio = toMinutes(hora_inicio);
    const nuevaFin = hora_fin ? toMinutes(hora_fin) : nuevaInicio + 40;

    const query = this.citaRepo
      .createQueryBuilder('cita')
      .where('cita.paciente_id = :paciente_id', { paciente_id })
      .andWhere('cita.fecha = :fecha', { fecha })
      .andWhere('cita.flg_activo = 1');

    if (excludeCitaId) {
      query.andWhere('cita.id != :excludeId', { excludeId: excludeCitaId });
    }

    const citasExistentes = await query.getMany();

    for (const cita of citasExistentes) {
      const existInicio = toMinutes(cita.hora_inicio);
      const existFin = cita.hora_fin
        ? toMinutes(cita.hora_fin)
        : existInicio + (cita.duracion_minutos || 40);

      const hayConflicto =
        (nuevaInicio >= existInicio && nuevaInicio < existFin) ||
        (nuevaFin > existInicio && nuevaFin <= existFin) ||
        (nuevaInicio <= existInicio && nuevaFin >= existFin);

      if (hayConflicto) {
        const ini = cita.hora_inicio.substring(0, 5);
        const fin = cita.hora_fin?.substring(0, 5) ?? `${Math.floor(existFin / 60).toString().padStart(2, '0')}:${(existFin % 60).toString().padStart(2, '0')}`;
        throw new BadRequestException(
          `El paciente ya tiene una cita agendada en ese horario (${ini} - ${fin}). No se pueden superponer citas.`,
        );
      }
    }
  }

  async crear(dto: CrearCitaDto): Promise<any> {
    // Validar que el paciente no tenga otra cita solapada ese día
    await this.verificarConflictoPaciente(
      dto.paciente_id,
      dto.fecha,
      dto.hora_inicio,
      dto.hora_fin,
    );

    const tipoCita = await this.determinarTipoCita(dto.motivo_id);
    console.log(`🔍 Creando cita tipo: ${tipoCita}`);

    if (tipoCita === 'NORMAL') {
      return this.crearCitaNormal(dto);
    } else if (tipoCita === 'REUNION_CLINICA') {
      return this.crearReunionClinica(dto);
    } else if (tipoCita === 'VISITA_ESCOLAR') {
      return this.crearVisitaEscolar(dto);
    }

    throw new BadRequestException('Tipo de cita no soportado');
  }

  
  private async crearCitaNormal(dto: CrearCitaDto): Promise<Cita> {
    if (!dto.doctor_id || !dto.servicio_id) {
      throw new BadRequestException('Se requiere doctor_id y servicio_id para cita normal');
    }

    const cita = this.citaRepo.create({
      paciente_id: dto.paciente_id,
      doctor_id: dto.doctor_id,
      servicio_id: dto.servicio_id,
      compra_id: dto.compra_id || null, // 🛒 Vincular con compra
      motivo_id: dto.motivo_id,
      estado_id: dto.estado_id,
      fecha: dto.fecha,
      hora_inicio: dto.hora_inicio,
      hora_fin: dto.hora_fin,
      duracion_minutos: dto.duracion_minutos,
      nota: dto.nota,
      firma_documento: false,
      user_id_crea: dto.user_id_crea,
    });

    const guardada = await this.citaRepo.save(cita);
    console.log(`✅ Cita normal creada: ID ${guardada.id}`);

    // 🛒 Si la cita está vinculada a una compra, descontar sesión
    if (dto.compra_id) {
      try {
        await this.compraService.usarSesion(dto.compra_id);
        console.log(`✅ Sesión descontada de compra ID ${dto.compra_id}`);
      } catch (error) {
        // Si falla, eliminar la cita creada
        await this.citaRepo.remove(guardada);
        throw new BadRequestException(`Error al descontar sesión: ${error.message}`);
      }
    }

    // Registrar en historial
    await this.historialService.registrarHistorial(
      guardada.id,
      'CREATE',
      dto.user_id_crea,
    );

    return guardada;
  }

// Agrega este método a tu CitasService (citas.service.ts)

async crearMultiples(citas: CrearCitaDto[]): Promise<any> {
  console.log(`🔍 Creando ${citas.length} citas...`);
  
  const resultados = [];
  const errores = [];

  for (let i = 0; i < citas.length; i++) {
    try {
      const citaCreada = await this.crear(citas[i]);
      resultados.push({
        index: i,
        cita: citaCreada,
        exito: true
      });
      console.log(`✅ Cita ${i + 1}/${citas.length} creada con éxito`);
    } catch (error) {
      errores.push({
        index: i,
        error: error.message,
        cita: citas[i]
      });
      console.log(`❌ Error al crear cita ${i + 1}/${citas.length}: ${error.message}`);
    }
  }

  console.log(`✅ Proceso completado: ${resultados.length} exitosas, ${errores.length} fallidas`);

  return {
    total: citas.length,
    exitosas: resultados.length,
    fallidas: errores.length,
    resultados,
    errores
  };
}

  private async crearReunionClinica(dto: CrearCitaDto): Promise<any> {
    if (!dto.terapeutas_ids || dto.terapeutas_ids.length === 0) {
      throw new BadRequestException('Se requiere al menos un terapeuta para reunión clínica');
    }

    if (!dto.servicios_ids || dto.servicios_ids.length === 0) {
      throw new BadRequestException('Se requiere al menos un servicio para reunión clínica');
    }

    // Crear cita base SIN doctor_id ni servicio_id (porque son múltiples)
    const cita = this.citaRepo.create({
      paciente_id: dto.paciente_id,
      doctor_id: null as any, // Se pondrá NULL en BD
      servicio_id: null as any, // Se pondrá NULL en BD
      motivo_id: dto.motivo_id,
      estado_id: dto.estado_id,
      fecha: dto.fecha,
      hora_inicio: dto.hora_inicio,
      hora_fin: dto.hora_fin,
      duracion_minutos: dto.duracion_minutos,
      nota: dto.nota,
      firma_documento: dto.firma_documento || false,
      user_id_crea: dto.user_id_crea,
    });

    const citaGuardada = await this.citaRepo.save(cita);
    console.log(`✅ Cita base para reunión clínica creada: ID ${citaGuardada.id}`);

    // Crear registro de reunión clínica relacionado con id_cita
    const reunion = this.reunionRepo.create({
      id_cita: citaGuardada.id,
      estado_cita_id: dto.estado_id,
      user_id_crea: dto.user_id_crea,
    });
    const reunionGuardada = await this.reunionRepo.save(reunion);
    console.log(`✅ Registro de reunión clínica creado con ID: ${reunionGuardada.id}`);

    // Agregar terapeutas
    for (const terapeuta_id of dto.terapeutas_ids) {
      await this.reunionTerapeutasRepo.save({
        id_reunion: reunionGuardada.id,
        id_terapeuta: terapeuta_id,
        user_id_crea: dto.user_id_crea,
      });
    }
    console.log(`✅ ${dto.terapeutas_ids.length} terapeutas agregados`);

    // Agregar servicios
    for (const servicio_id of dto.servicios_ids) {
      await this.reunionServiciosRepo.save({
        id_reunion: reunionGuardada.id,
        id_servicio: servicio_id,
        user_id_crea: dto.user_id_crea,
      });
    }
    console.log(`✅ ${dto.servicios_ids.length} servicios agregados`);

    // Registrar en historial
    await this.historialService.registrarHistorial(
      citaGuardada.id,
      'CREATE',
      dto.user_id_crea,
    );

    return citaGuardada;
  }

  private async crearVisitaEscolar(dto: CrearCitaDto): Promise<Cita> {
    if (!dto.doctor_id) {
      throw new BadRequestException('Se requiere doctor_id para visita escolar');
    }

    if (!dto.encargado || !dto.encargado.institucion || !dto.encargado.nombre_completo) {
      throw new BadRequestException('Se requieren datos del encargado para visita escolar');
    }

    // Crear cita base
    const cita = this.citaRepo.create({
      paciente_id: dto.paciente_id,
      doctor_id: dto.doctor_id,
      servicio_id: dto.servicio_id || null,
      motivo_id: dto.motivo_id,
      estado_id: dto.estado_id,
      fecha: dto.fecha,
      hora_inicio: dto.hora_inicio,
      hora_fin: dto.hora_fin,
      duracion_minutos: dto.duracion_minutos,
      nota: dto.nota,
      firma_documento: dto.firma_documento || false,
      user_id_crea: dto.user_id_crea,
    });

    const citaGuardada = await this.citaRepo.save(cita);
    console.log(`✅ Cita base creada para visita escolar: ID ${citaGuardada.id}`);

    // Crear registro de visita escolar
    await this.visitaEscolarRepo.save({
      id_cita: citaGuardada.id,
      nombre_colegio: dto.encargado.institucion,
      nombre_intermediario: dto.encargado.nombre_completo,
      telefono: dto.encargado.telefono,
      observaciones: dto.nota,
      user_id_crea: dto.user_id_crea,
    });
    console.log(`✅ Datos de visita escolar agregados`);

    // Registrar en historial
    await this.historialService.registrarHistorial(
      citaGuardada.id,
      'CREATE',
      dto.user_id_crea,
    );

    return citaGuardada;
  }

async listar(filtros: any = {}): Promise<any[]> {
  const terapeutaId = filtros.terapeuta_id ? parseInt(filtros.terapeuta_id) : null;
  console.log(`🔍 Listando citas. Filtro terapeuta_id: ${terapeutaId}`);

  // Formatear fechas como YYYY-MM-DD
  const formatearFecha = (fecha: Date) => {
    const year = fecha.getFullYear();
    const month = String(fecha.getMonth() + 1).padStart(2, '0');
    const day = String(fecha.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // 🚀 FILTRO POR RANGO DE FECHAS
  // Si no se envían fechas, usar el mes actual para evitar cargar 1000+ citas
  let fechaDesde: string;
  let fechaHasta: string;

  if (filtros.fecha_desde && filtros.fecha_hasta) {
    // Usar las fechas enviadas desde el frontend
    fechaDesde = filtros.fecha_desde;
    fechaHasta = filtros.fecha_hasta;
    console.log(`📅 Usando rango de fechas del frontend: ${fechaDesde} al ${fechaHasta}`);
  } else {
    // Fallback: usar mes actual
    const hoy = new Date();
    const primerDiaMes = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
    const ultimoDiaMes = new Date(hoy.getFullYear(), hoy.getMonth() + 1, 0);
    fechaDesde = formatearFecha(primerDiaMes);
    fechaHasta = formatearFecha(ultimoDiaMes);
    console.log(`📅 Usando mes actual por defecto: ${fechaDesde} al ${fechaHasta}`);
  }

  // 1. Obtener CITAS NORMALES del mes actual
  const whereNormales: any = {
    fecha: this.citaRepo.createQueryBuilder()
      .where('fecha >= :fechaDesde', { fechaDesde })
      .andWhere('fecha <= :fechaHasta', { fechaHasta })
      .getQuery() ? undefined : undefined
  };

  if (terapeutaId) {
    whereNormales.doctor_id = terapeutaId;
  }

  const citasNormales = await this.citaRepo
    .createQueryBuilder('cita')
    .leftJoinAndSelect('cita.paciente', 'paciente')
    .leftJoinAndSelect('cita.doctor', 'doctor')
    .leftJoinAndSelect('cita.servicio', 'servicio')
    .leftJoinAndSelect('cita.motivo', 'motivo')
    .leftJoinAndSelect('cita.estado', 'estado')
    .where('cita.fecha >= :fechaDesde', { fechaDesde })
    .andWhere('cita.fecha <= :fechaHasta', { fechaHasta })
    .andWhere('cita.flg_activo = 1')
    .andWhere(terapeutaId ? 'cita.doctor_id = :terapeutaId' : '1=1', { terapeutaId })
    .orderBy('cita.fecha', 'ASC')
    .addOrderBy('cita.hora_inicio', 'ASC')
    .getMany();

  // 2. Obtener REUNIONES CLÍNICAS del mes actual
  let reuniones = [];
  const reunionesIds = await this.reunionRepo.find();

  console.log(`📋 Total reuniones encontradas: ${reunionesIds.length}`);

  for (const r of reunionesIds) {
    // 🔥 Soportar registros antiguos (id_cita = NULL) y nuevos (id_cita = X)
    const idCitaBuscar = r.id_cita || r.id; // Si id_cita es NULL, usar el id de la reunión (estructura antigua)

    console.log(`🔍 Procesando reunión ID: ${r.id}, id_cita: ${r.id_cita}, buscando cita con ID: ${idCitaBuscar}`);

    // Primero verificar si la cita está en el rango de fechas y activa
    const citaBase = await this.citaRepo
      .createQueryBuilder('cita')
      .where('cita.id = :id', { id: idCitaBuscar })
      .andWhere('cita.fecha >= :fechaDesde', { fechaDesde })
      .andWhere('cita.fecha <= :fechaHasta', { fechaHasta })
      .andWhere('cita.flg_activo = 1')
      .getOne();

    if (!citaBase) {
      console.log(`❌ Cita ${idCitaBuscar} NO encontrada en rango de fechas o está inactiva`);
      continue; // Saltar si no está en el mes actual o está eliminada
    }

    console.log(`✅ Cita ${idCitaBuscar} encontrada: ${citaBase.fecha}`);

    const reunion = await this.reunionRepo.findOne({
      where: { id: r.id },
      relations: ['terapeutas', 'terapeutas.terapeuta', 'servicios', 'servicios.servicio'],
    });

    if (!reunion) continue;

    if (terapeutaId) {
      const tieneTerapeuta = reunion.terapeutas.some(t => t.id_terapeuta === terapeutaId);
      if (!tieneTerapeuta) continue;
    }

    const cita = await this.citaRepo.findOne({
      where: { id: idCitaBuscar },
      relations: ['paciente', 'motivo', 'estado'],
    });

    if (cita) {
      reuniones.push({
        ...cita,
        terapeutas: reunion.terapeutas,
        servicios: reunion.servicios,
        tipo_cita: 'REUNION_CLINICA'
      });
    }
  }

  // 3. Obtener VISITAS ESCOLARES del mes actual
  let visitas = [];
  const visitasIds = await this.visitaEscolarRepo.find({ select: ['id_cita'] });

  for (const v of visitasIds) {
    const cita = await this.citaRepo
      .createQueryBuilder('cita')
      .leftJoinAndSelect('cita.paciente', 'paciente')
      .leftJoinAndSelect('cita.doctor', 'doctor')
      .leftJoinAndSelect('cita.servicio', 'servicio')
      .leftJoinAndSelect('cita.motivo', 'motivo')
      .leftJoinAndSelect('cita.estado', 'estado')
      .where('cita.id = :id', { id: v.id_cita })
      .andWhere('cita.fecha >= :fechaDesde', { fechaDesde })
      .andWhere('cita.fecha <= :fechaHasta', { fechaHasta })
      .andWhere('cita.flg_activo = 1')
      .andWhere(terapeutaId ? 'cita.doctor_id = :terapeutaId' : '1=1', { terapeutaId })
      .getOne();

    if (cita) {
      const visita = await this.visitaEscolarRepo.findOne({
        where: { id_cita: v.id_cita },
      });

      visitas.push({
        ...cita,
        nombre_colegio: visita.nombre_colegio,
        nombre_intermediario: visita.nombre_intermediario,
        telefono: visita.telefono,
        observaciones: visita.observaciones,
        tipo_cita: 'VISITA_ESCOLAR',
        id: cita.id
      });
    }
  }

  // 4. Filtrar citas normales
  const idsReuniones = new Set(reunionesIds.map(r => r.id));
  const idsVisitas = new Set(visitasIds.map(v => v.id_cita));

  const citasNormalesFiltered = citasNormales
    .filter(c => !idsReuniones.has(c.id) && !idsVisitas.has(c.id))
    .map(c => ({ ...c, tipo_cita: 'NORMAL' }));

  // 5. Unificar y ordenar
  const todasLasCitas = [...citasNormalesFiltered, ...reuniones, ...visitas];

  console.log(`✅ Total citas: ${todasLasCitas.length} (Normales: ${citasNormalesFiltered.length}, Reuniones: ${reuniones.length}, Visitas: ${visitas.length})`);

  return todasLasCitas.sort((a, b) => {
    const fechaA = new Date(`${a.fecha} ${a.hora_inicio}`);
    const fechaB = new Date(`${b.fecha} ${b.hora_inicio}`);
    return fechaA.getTime() - fechaB.getTime();
  });
}
  async obtenerPorId(id: number): Promise<any> {
    console.log(`🔍 Buscando cita con ID: ${id}`);

    // Buscar en citas base
    const cita = await this.citaRepo.findOne({
      where: { id },
      relations: ['paciente', 'doctor', 'servicio', 'motivo', 'estado'],
    });

    if (!cita) {
      console.log(`❌ Cita con ID ${id} NO encontrada en tabla citas`);
      throw new NotFoundException(`Cita con ID ${id} no encontrada`);
    }

    console.log(`✅ Cita encontrada. Paciente: ${cita.paciente?.nombres || 'N/A'}`);

    // Verificar si es reunión clínica (soportar registros antiguos y nuevos)
    let reunion = await this.reunionRepo.findOne({
      where: { id_cita: id },
      relations: ['terapeutas', 'terapeutas.terapeuta', 'servicios', 'servicios.servicio'],
    });

    // 🔥 Si no se encontró por id_cita, buscar por id (registros antiguos con id_cita = NULL)
    if (!reunion) {
      reunion = await this.reunionRepo.findOne({
        where: { id: id },
        relations: ['terapeutas', 'terapeutas.terapeuta', 'servicios', 'servicios.servicio'],
      });
    }

    if (reunion) {
      console.log(`📋 Es REUNIÓN CLÍNICA con ${reunion.terapeutas?.length || 0} terapeutas`);
      return {
        ...cita,
        terapeutas: reunion.terapeutas,
        servicios: reunion.servicios,
        tipo_cita: 'REUNION_CLINICA'
      };
    }

    // Verificar si es visita escolar
    const visita = await this.visitaEscolarRepo.findOne({
      where: { id_cita: id },
    });

    if (visita) {
      console.log(`🏫 Es VISITA ESCOLAR a ${visita.nombre_colegio}`);
      return {
        ...cita,
        nombre_colegio: visita.nombre_colegio,
        nombre_intermediario: visita.nombre_intermediario,
        telefono: visita.telefono,
        observaciones: visita.observaciones,
        tipo_cita: 'VISITA_ESCOLAR'
      };
    }

    console.log(`📝 Es CITA NORMAL`);
    return { ...cita, tipo_cita: 'NORMAL' };
  }
  async actualizar(id: number, dto: CrearCitaDto): Promise<any> {
  // ✅ VALIDAR MOTIVO DE ACCIÓN (OBLIGATORIO PARA UPDATE)
  if (!dto.motivo_accion || dto.motivo_accion.trim() === '') {
    throw new BadRequestException('El motivo de la modificación es obligatorio');
  }

  // Validar que el paciente no tenga otra cita solapada (excluyendo la cita actual)
  await this.verificarConflictoPaciente(
    dto.paciente_id,
    dto.fecha,
    dto.hora_inicio,
    dto.hora_fin,
    id,
  );

  const tipoCita = await this.determinarTipoCita(dto.motivo_id);
  console.log(`🔍 Actualizando cita ID ${id}, tipo: ${tipoCita}`);
  console.log(`📝 Motivo de modificación: ${dto.motivo_accion}`);

  // Obtener la cita existente con todas sus relaciones ANTES de actualizar
  const citaAntigua = await this.citaRepo.findOne({
    where: { id },
    relations: ['paciente', 'doctor', 'servicio', 'motivo', 'estado'],
  });

  if (!citaAntigua) {
    throw new NotFoundException(`Cita con ID ${id} no encontrada`);
  }

  // 🔥 Cargar datos específicos según tipo de cita ANTES de actualizar
  let datosAntiguosCompletos: any = {
    ...citaAntigua,
    servicioNombre: citaAntigua.servicio?.nombre || null,
    doctorNombre: citaAntigua.doctor
      ? `${citaAntigua.doctor.nombres} ${citaAntigua.doctor.apellidos}`.trim()
      : null,
  };

  if (tipoCita === 'VISITA_ESCOLAR') {
    const visitaAntigua = await this.visitaEscolarRepo.findOne({
      where: { id_cita: id }
    });
    if (visitaAntigua) {
      datosAntiguosCompletos = {
        ...datosAntiguosCompletos,
        nombre_colegio: visitaAntigua.nombre_colegio,
        nombre_intermediario: visitaAntigua.nombre_intermediario,
        telefono: visitaAntigua.telefono,
        observaciones: visitaAntigua.observaciones,
      };
    }
  } else if (tipoCita === 'REUNION_CLINICA') {
    const reunionAntigua = await this.reunionRepo.findOne({
      where: { id_cita: id },
      relations: ['terapeutas', 'servicios']
    });
    if (reunionAntigua) {
      // Cargar nombres de terapeutas antiguos
      const terapeutasAntiguos = await this.reunionTerapeutasRepo.find({
        where: { id_reunion: reunionAntigua.id }
      });
      const terapeutasIds = terapeutasAntiguos.map(t => t.id_terapeuta);

      let terapeutasNombresAntiguos = [];
      if (terapeutasIds.length > 0) {
        const queryTerapeutas = `SELECT id, nombres, apellidos FROM trabajador_centro WHERE id IN (?)`;
        const terapeutas = await this.citaRepo.query(queryTerapeutas, [terapeutasIds]);
        terapeutasNombresAntiguos = terapeutas.map(t => `${t.nombres} ${t.apellidos}`.trim());
      }

      // Cargar nombres de servicios antiguos
      const serviciosAntiguos = await this.reunionServiciosRepo.find({
        where: { id_reunion: reunionAntigua.id }
      });
      const serviciosIds = serviciosAntiguos.map(s => s.id_servicio);

      let serviciosNombresAntiguos = [];
      if (serviciosIds.length > 0) {
        const queryServicios = `SELECT id, nombre FROM servicios WHERE id IN (?)`;
        const servicios = await this.citaRepo.query(queryServicios, [serviciosIds]);
        serviciosNombresAntiguos = servicios.map(s => s.nombre);
      }

      datosAntiguosCompletos = {
        ...datosAntiguosCompletos,
        reunion_clinica: reunionAntigua,
        terapeutasNombres: terapeutasNombresAntiguos.join(', '),
        serviciosNombres: serviciosNombresAntiguos.join(', '),
      };
    }
  }

  // Guardar datos antiguos para la notificación
  const datosAntiguos = {
    fecha: citaAntigua.fecha,
    hora_inicio: citaAntigua.hora_inicio,
    doctor_id: citaAntigua.doctor_id,
    doctor_nombre: citaAntigua.doctor
      ? `${citaAntigua.doctor.nombres} ${citaAntigua.doctor.apellidos}`
      : 'No asignado',
  };

  // Actualizar según tipo
  let resultado;
  if (tipoCita === 'NORMAL') {
    resultado = await this.actualizarCitaNormal(id, dto);
  } else if (tipoCita === 'REUNION_CLINICA') {
    resultado = await this.actualizarReunionClinica(id, dto);
  } else if (tipoCita === 'VISITA_ESCOLAR') {
    resultado = await this.actualizarVisitaEscolar(id, dto);
  } else {
    throw new BadRequestException('Tipo de cita no soportado');
  }

  // 🔔 Disparar notificación de cita modificada
  try {
    // Obtener información del usuario que modifica
    const queryUsuario = `SELECT nombres, apellidos FROM trabajador_centro WHERE id = ?`;
    const usuario = await this.citaRepo.query(queryUsuario, [dto.user_id_crea]);
    const nombreUsuario = usuario && usuario.length > 0
      ? `${usuario[0].nombres} ${usuario[0].apellidos}`
      : 'Usuario desconocido';

    // Obtener nombre del paciente
    const pacienteNombre = citaAntigua.paciente
      ? `${citaAntigua.paciente.nombres} ${citaAntigua.paciente.apellido_paterno} ${citaAntigua.paciente.apellido_materno || ''}`.trim()
      : 'Paciente desconocido';

    // Obtener nombre del nuevo terapeuta si cambió
    let nuevoTerapeutaNombre = datosAntiguos.doctor_nombre;
    if (dto.doctor_id && dto.doctor_id !== datosAntiguos.doctor_id) {
      const queryTerapeuta = `SELECT nombres, apellidos FROM trabajador_centro WHERE id = ?`;
      const terapeuta = await this.citaRepo.query(queryTerapeuta, [dto.doctor_id]);
      nuevoTerapeutaNombre = terapeuta && terapeuta.length > 0
        ? `${terapeuta[0].nombres} ${terapeuta[0].apellidos}`
        : 'Terapeuta desconocido';
    }

    await this.notificacionesService.notificarCitaModificada(
        id,                              // citaId
      dto.user_id_crea,                // usuarioModificadorId
      nombreUsuario,                   // nombreUsuarioModificador
      pacienteNombre,                  // pacienteNombre
      datosAntiguos.fecha,             // fechaAnterior
      datosAntiguos.hora_inicio,       // horaAnterior
      datosAntiguos.doctor_nombre,     // terapeutaNombre
      datosAntiguos.doctor_id,         // 👈 terapeutaId (agregado)
      dto.fecha,                       // 👈 fechaNueva (corregido)
      dto.hora_inicio,                 // 👈 horaNueva (corregido)
      dto.motivo_accion, 
    );
  } catch (error) {
    console.error('❌ Error al crear notificación de cita modificada:', error.message);
    // No detener la actualización si falla la notificación
  }

  // Retornar datos anteriores y nuevos para auditoría detallada
  return {
    datosAnteriores: datosAntiguosCompletos,
    datosNuevos: resultado,
    ...resultado  // Spread para mantener compatibilidad con código existente
  };
}

private async actualizarCitaNormal(id: number, dto: CrearCitaDto): Promise<any> {
  if (!dto.doctor_id || !dto.servicio_id) {
    throw new BadRequestException('Se requiere doctor_id y servicio_id para cita normal');
  }

  await this.citaRepo.update(id, {
    paciente_id: dto.paciente_id,
    doctor_id: dto.doctor_id,
    servicio_id: dto.servicio_id,
    motivo_id: dto.motivo_id,
    estado_id: dto.estado_id,
    fecha: dto.fecha,
    hora_inicio: dto.hora_inicio,
    hora_fin: dto.hora_fin,
    duracion_minutos: dto.duracion_minutos,
    nota: dto.nota,
    user_id_actua: dto.user_id_crea,
  });

  console.log(`✅ Cita normal actualizada: ID ${id}`);

  // Registrar en historial con motivo
  await this.historialService.registrarHistorial(
    id,
    'UPDATE',
    dto.user_id_crea,
    undefined,
    dto.motivo_accion,
  );

  const citaActualizada = await this.citaRepo.findOne({
    where: { id },
    relations: ['paciente', 'doctor', 'servicio', 'motivo', 'estado']
  });

  // 🔥 Retornar con motivo y nombres para auditoría
  return {
    ...citaActualizada,
    servicioNombre: citaActualizada.servicio?.nombre || null,
    doctorNombre: citaActualizada.doctor
      ? `${citaActualizada.doctor.nombres} ${citaActualizada.doctor.apellidos}`.trim()
      : null,
    motivo_accion: dto.motivo_accion
  };
}

private async actualizarReunionClinica(id: number, dto: CrearCitaDto): Promise<any> {
  if (!dto.terapeutas_ids || dto.terapeutas_ids.length === 0) {
    throw new BadRequestException('Se requiere al menos un terapeuta para reunión clínica');
  }

  if (!dto.servicios_ids || dto.servicios_ids.length === 0) {
    throw new BadRequestException('Se requiere al menos un servicio para reunión clínica');
  }

  // Actualizar cita base
  await this.citaRepo.update(id, {
    paciente_id: dto.paciente_id,
    motivo_id: dto.motivo_id,
    estado_id: dto.estado_id,
    fecha: dto.fecha,
    hora_inicio: dto.hora_inicio,
    hora_fin: dto.hora_fin,
    duracion_minutos: dto.duracion_minutos,
    nota: dto.nota,
    user_id_actua: dto.user_id_crea,
  });

  console.log(`✅ Cita base actualizada: ID ${id}`);

  // Buscar el registro de reunión clínica por id_cita (soportar registros antiguos y nuevos)
  let reunion = await this.reunionRepo.findOne({ where: { id_cita: id } });

  // 🔥 Si no se encontró por id_cita, buscar por id (registros antiguos con id_cita = NULL)
  if (!reunion) {
    reunion = await this.reunionRepo.findOne({ where: { id: id } });
  }

  if (!reunion) {
    throw new BadRequestException(`No se encontró reunión clínica para la cita ${id}`);
  }

  // Actualizar registro de reunión clínica
  await this.reunionRepo.update(reunion.id, {
    estado_cita_id: dto.estado_id,
    user_id_actua: dto.user_id_crea,
  });

  // Eliminar terapeutas anteriores
  await this.reunionTerapeutasRepo.delete({ id_reunion: reunion.id });

  // Agregar nuevos terapeutas
  for (const terapeuta_id of dto.terapeutas_ids) {
    await this.reunionTerapeutasRepo.save({
      id_reunion: reunion.id,
      id_terapeuta: terapeuta_id,
      user_id_crea: dto.user_id_crea,
    });
  }
  console.log(`✅ ${dto.terapeutas_ids.length} terapeutas actualizados`);

  // Eliminar servicios anteriores
  await this.reunionServiciosRepo.delete({ id_reunion: reunion.id });

  // Agregar nuevos servicios
  for (const servicio_id of dto.servicios_ids) {
    await this.reunionServiciosRepo.save({
      id_reunion: reunion.id,
      id_servicio: servicio_id,
      user_id_crea: dto.user_id_crea,
    });
  }
  console.log(`✅ ${dto.servicios_ids.length} servicios actualizados`);

  // Registrar en historial con motivo
  await this.historialService.registrarHistorial(
    id,
    'UPDATE',
    dto.user_id_crea,
    undefined,
    dto.motivo_accion,
  );

  const citaActualizada = await this.citaRepo.findOne({
    where: { id },
    relations: ['paciente', 'doctor', 'servicio', 'motivo', 'estado']
  });

  // 🔥 Cargar datos actualizados de reunión clínica con nombres
  let reunionFinal = await this.reunionRepo.findOne({
    where: { id_cita: id },
    relations: ['terapeutas', 'servicios']
  });
  if (!reunionFinal) {
    reunionFinal = await this.reunionRepo.findOne({
      where: { id: id },
      relations: ['terapeutas', 'servicios']
    });
  }

  // Cargar nombres de terapeutas
  let terapeutasNombres = [];
  if (dto.terapeutas_ids && dto.terapeutas_ids.length > 0) {
    const queryTerapeutas = `SELECT id, nombres, apellidos FROM trabajador_centro WHERE id IN (?)`;
    const terapeutas = await this.citaRepo.query(queryTerapeutas, [dto.terapeutas_ids]);
    terapeutasNombres = terapeutas.map(t => `${t.nombres} ${t.apellidos}`.trim());
  }

  // Cargar nombres de servicios
  let serviciosNombres = [];
  if (dto.servicios_ids && dto.servicios_ids.length > 0) {
    const queryServicios = `SELECT id, nombre FROM servicios WHERE id IN (?)`;
    const servicios = await this.citaRepo.query(queryServicios, [dto.servicios_ids]);
    serviciosNombres = servicios.map(s => s.nombre);
  }

  const reunionActualizada = reunionFinal ? {
    estado_cita_id: reunionFinal.estado_cita_id,
    terapeutas_ids: dto.terapeutas_ids,
    terapeutasNombres: terapeutasNombres.join(', '),
    servicios_ids: dto.servicios_ids,
    serviciosNombres: serviciosNombres.join(', '),
  } : null;

  // 🔥 Retornar con motivo y datos específicos de reunión clínica para auditoría
  return {
    ...citaActualizada,
    reunion_clinica: reunionActualizada,
    terapeutasNombres: terapeutasNombres.join(', '),
    serviciosNombres: serviciosNombres.join(', '),
    motivo_accion: dto.motivo_accion
  };
}

private async actualizarVisitaEscolar(id: number, dto: CrearCitaDto): Promise<any> {
  if (!dto.doctor_id) {
    throw new BadRequestException('Se requiere doctor_id para visita escolar');
  }

  if (!dto.encargado || !dto.encargado.institucion || !dto.encargado.nombre_completo) {
    throw new BadRequestException('Se requieren datos del encargado para visita escolar');
  }

  // Actualizar cita base
  await this.citaRepo.update(id, {
    paciente_id: dto.paciente_id,
    doctor_id: dto.doctor_id,
    servicio_id: dto.servicio_id || null,
    motivo_id: dto.motivo_id,
    estado_id: dto.estado_id,
    fecha: dto.fecha,
    hora_inicio: dto.hora_inicio,
    hora_fin: dto.hora_fin,
    duracion_minutos: dto.duracion_minutos,
    nota: dto.nota,
    firma_documento: dto.firma_documento || false,
    user_id_actua: dto.user_id_crea,
  });

  console.log(`✅ Cita base actualizada: ID ${id}`);

  // Actualizar datos de visita escolar
  await this.visitaEscolarRepo.update(
    { id_cita: id },
    {
      nombre_colegio: dto.encargado.institucion,
      nombre_intermediario: dto.encargado.nombre_completo,
      telefono: dto.encargado.telefono,
      observaciones: dto.nota,
      user_id_actua: dto.user_id_crea,
    }
  );

  console.log(`✅ Datos de visita escolar actualizados`);

  // Registrar en historial con motivo
  await this.historialService.registrarHistorial(
    id,
    'UPDATE',
    dto.user_id_crea,
    undefined,
    dto.motivo_accion,
  );

  const citaActualizada = await this.citaRepo.findOne({
    where: { id },
    relations: ['paciente', 'doctor', 'servicio', 'motivo', 'estado']
  });

  // 🔥 Cargar datos actualizados de visita escolar
  const visitaActualizada = await this.visitaEscolarRepo.findOne({
    where: { id_cita: id }
  });

  // 🔥 Retornar con motivo y datos específicos de visita escolar para auditoría
  return {
    ...citaActualizada,
    servicioNombre: citaActualizada.servicio?.nombre || null,
    doctorNombre: citaActualizada.doctor
      ? `${citaActualizada.doctor.nombres} ${citaActualizada.doctor.apellidos}`.trim()
      : null,
    nombre_colegio: visitaActualizada?.nombre_colegio,
    nombre_intermediario: visitaActualizada?.nombre_intermediario,
    telefono: visitaActualizada?.telefono,
    observaciones: visitaActualizada?.observaciones,
    motivo_accion: dto.motivo_accion
  };
}

  async eliminar(id: number, usuarioId?: number, motivoAccion?: string): Promise<any> {
    // ✅ VALIDAR MOTIVO DE ACCIÓN (OBLIGATORIO PARA DELETE)
    if (!motivoAccion || motivoAccion.trim() === '') {
      throw new BadRequestException('El motivo de eliminación es obligatorio');
    }

    console.log(`🗑️ Eliminando (soft delete) cita ID ${id}`);
    console.log(`📝 Motivo de eliminación: ${motivoAccion}`);

    // Obtener la cita con todas sus relaciones para auditoría
    const cita = await this.citaRepo.findOne({
      where: { id },
      relations: ['paciente', 'doctor', 'servicio', 'motivo', 'estado'],
    });

    if (!cita) {
      throw new NotFoundException(`Cita con ID ${id} no encontrada`);
    }

    // Verificar si ya está eliminada
    if (cita.flg_activo === 0) {
      throw new BadRequestException('La cita ya fue eliminada');
    }

    // Obtener información del usuario que elimina
    const query = `SELECT nombres, apellidos FROM trabajador_centro WHERE id = ?`;
    const usuario = await this.citaRepo.query(query, [usuarioId || cita.user_id_crea]);
    const nombreUsuario = usuario && usuario.length > 0
      ? `${usuario[0].nombres} ${usuario[0].apellidos}`
      : 'Usuario desconocido';

    // Registrar en historial ANTES de "eliminar" (con motivo)
    await this.historialService.registrarHistorial(
      id,
      'DELETE',
      usuarioId || cita.user_id_crea,
      undefined,
      motivoAccion,
    );

    // 🔔 Disparar notificación de cita eliminada
    try {
      const pacienteNombre = cita.paciente
        ? `${cita.paciente.nombres} ${cita.paciente.apellido_paterno} ${cita.paciente.apellido_materno || ''}`.trim()
        : 'Paciente desconocido';

      const terapeutaNombre = cita.doctor
        ? `${cita.doctor.nombres} ${cita.doctor.apellidos}`
        : 'Terapeuta no asignado';

      await this.notificacionesService.notificarCitaEliminada(
        id,
        usuarioId || cita.user_id_crea,
        nombreUsuario,
        pacienteNombre,
        cita.fecha,
        cita.hora_inicio,
        terapeutaNombre,
        motivoAccion,
      );
    } catch (error) {
      console.error('❌ Error al crear notificación de cita eliminada:', error.message);
      // No detener la eliminación si falla la notificación
    }

    // ✅ SOFT DELETE: Marcar como eliminado en lugar de borrar físicamente
    await this.citaRepo.update(id, {
      flg_activo: 0,
      user_id_actua: usuarioId || cita.user_id_crea,
    });
    console.log(`✅ Cita ${id} marcada como eliminada (flg_activo = 0)`);

    // 🔥 Retornar con motivo y datos de la cita para auditoría
    return {
      mensaje: 'Cita eliminada correctamente',
      motivo_accion: motivoAccion,
      cita: cita
    };
  }

  async getMotivosCita(): Promise<MotivoCita[]> {
    return this.motivoRepo.find({
      where: { activo: true },
      relations: ['tipoCita'],
      order: { nombre: 'ASC' },
    });
  }

  async getEstadosCita(): Promise<EstadoCita[]> {
    return this.estadoRepo.find({
      where: { activo: true },
      order: { nombre: 'ASC' },
    });
  }

  async getTiposCita(): Promise<TipoCita[]> {
    return this.tipoRepo.find({
      where: { activo: true },
      order: { nombre: 'ASC' },
    });
  }


/**
 * Obtener estadísticas de citas
 * @param fechaDesde - Primer día del mes visible (YYYY-MM-DD)
 * @param fechaHasta - Último día del mes visible (YYYY-MM-DD)
 * @param terapeutaId - ID del terapeuta (opcional)
 * @param fechaReferencia - Fecha de referencia del calendario (YYYY-MM-DD)
 */
async obtenerEstadisticas(
  fechaDesde: string,
  fechaHasta: string,
  terapeutaId?: number,
  fechaReferencia?: string
): Promise<any> {
  console.log(`📊 Obteniendo estadísticas de citas`);
  console.log(`   - Rango mes visible: ${fechaDesde} al ${fechaHasta}`);
  console.log(`   - Terapeuta ID: ${terapeutaId || 'TODOS'}`);
  console.log(`   - Fecha de referencia: ${fechaReferencia || 'HOY (sin calendario)'}`);

  // Función auxiliar para formatear fechas
  const formatearFecha = (fecha: Date) => {
    const year = fecha.getFullYear();
    const month = String(fecha.getMonth() + 1).padStart(2, '0');
    const day = String(fecha.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // ===================================================================
  // DETERMINAR FECHA BASE PARA LOS CÁLCULOS
  // ===================================================================
  let fechaBase: Date;
  let esModoCalendario = false; // ¿Hay terapeuta seleccionado?

  if (fechaReferencia) {
    // Siempre usar la fecha de referencia del calendario si está disponible
    fechaBase = new Date(fechaReferencia + 'T00:00:00');
    esModoCalendario = !!terapeutaId; // true si hay terapeuta, false si es global
    console.log(`   ✅ Modo: ${esModoCalendario ? 'CALENDARIO (terapeuta seleccionado)' : 'GLOBAL (calendario visible)'}`);
    console.log(`   📅 Fecha base: ${formatearFecha(fechaBase)}`);
  } else {
    // Fallback: usar fecha actual de Perú (GMT-5)
    const ahora = new Date();
    const fechaPeru = new Date(ahora.toLocaleString('en-US', { timeZone: 'America/Lima' }));
    fechaBase = fechaPeru;
    console.log(`   ⚠️ Modo: FALLBACK (usando hora de Perú)`);
    console.log(`   📅 Fecha base: ${formatearFecha(fechaBase)}`);
  }

  // ===================================================================
  // 1. TOTAL DE CITAS DEL AÑO (excluyendo motivo_id = 7)
  // ===================================================================
  const anioBase = fechaBase.getFullYear();
  const inicioAnio = `${anioBase}-01-01`;
  const finAnio = `${anioBase}-12-31`;

  const queryAnio = this.citaRepo
    .createQueryBuilder('cita')
    .where('cita.fecha >= :inicioAnio', { inicioAnio })
    .andWhere('cita.fecha <= :finAnio', { finAnio })
    .andWhere('cita.flg_activo = 1')
    .andWhere('cita.motivo_id != 7'); // ❌ EXCLUIR reuniones clínicas

  if (terapeutaId) {
    queryAnio.andWhere('cita.doctor_id = :terapeutaId', { terapeutaId });
  }

  const totalCitasAnio = await queryAnio.getCount();

  // ===================================================================
  // 2. TOTAL DE CITAS DEL MES
  // ===================================================================
  let mesDesde: string;
  let mesHasta: string;

  if (esModoCalendario) {
    // Con calendario: usar el mes visible
    mesDesde = fechaDesde;
    mesHasta = fechaHasta;
  } else {
    // Sin calendario: usar el mes actual real
    const primerDiaMes = new Date(fechaBase.getFullYear(), fechaBase.getMonth(), 1);
    const ultimoDiaMes = new Date(fechaBase.getFullYear(), fechaBase.getMonth() + 1, 0);
    mesDesde = formatearFecha(primerDiaMes);
    mesHasta = formatearFecha(ultimoDiaMes);
  }

  const queryMes = this.citaRepo
    .createQueryBuilder('cita')
    .where('cita.fecha >= :mesDesde', { mesDesde })
    .andWhere('cita.fecha <= :mesHasta', { mesHasta })
    .andWhere('cita.flg_activo = 1')
    .andWhere('cita.motivo_id != 7'); // ❌ EXCLUIR reuniones clínicas

  if (terapeutaId) {
    queryMes.andWhere('cita.doctor_id = :terapeutaId', { terapeutaId });
  }

  const totalCitasMes = await queryMes.getCount();

  // ===================================================================
  // 3. TOTAL DE REUNIONES CLÍNICAS DEL MES (SOLO motivo_id = 7)
  // ===================================================================
  const queryReuniones = this.citaRepo
    .createQueryBuilder('cita')
    .innerJoin('cita_reunion_clinica', 'rc', 'rc.id_cita = cita.id')
    .where('cita.fecha >= :mesDesde', { mesDesde })
    .andWhere('cita.fecha <= :mesHasta', { mesHasta })
    .andWhere('cita.flg_activo = 1')
    .andWhere('cita.motivo_id = 7'); // ✅ SOLO reuniones clínicas

  if (terapeutaId) {
    console.log(`   🔍 Filtrando reuniones clínicas por terapeuta ID: ${terapeutaId}`);
    // Para reuniones clínicas, buscar en la tabla de terapeutas asociados
    queryReuniones.innerJoin(
      'cita_reunion_clinica_terapeutas',
      'rct',
      'rct.id_reunion = rc.id AND rct.id_terapeuta = :terapeutaId',
      { terapeutaId }
    );
  }

  // 🔥 LOG DE LA QUERY SQL GENERADA
  const sqlQuery = queryReuniones.getSql();
  console.log(`   🔍 SQL Query para reuniones clínicas:`);
  console.log(`   ${sqlQuery}`);
  console.log(`   📊 Parámetros: mesDesde=${mesDesde}, mesHasta=${mesHasta}, terapeutaId=${terapeutaId || 'N/A'}`);

  const totalReunionesClinicasMes = await queryReuniones.getCount();
  console.log(`   ✅ Reuniones clínicas encontradas: ${totalReunionesClinicasMes}`);

  // ===================================================================
  // 4. CITAS DE ESTA SEMANA (Lunes a Sábado) - SIN motivo_id = 7
  // ===================================================================
  const diaSemana = fechaBase.getDay(); // 0=domingo, 1=lunes, ..., 6=sábado
  const lunes = new Date(fechaBase);

  if (diaSemana === 0) {
    // Si es domingo, ir al lunes anterior
    lunes.setDate(fechaBase.getDate() - 6);
  } else {
    // Cualquier otro día, ir al lunes de esa semana
    lunes.setDate(fechaBase.getDate() - (diaSemana - 1));
  }

  const sabado = new Date(lunes);
  sabado.setDate(lunes.getDate() + 5); // Lunes + 5 días = Sábado

  const inicioSemana = formatearFecha(lunes);
  const finSemana = formatearFecha(sabado);

  const querySemana = this.citaRepo
    .createQueryBuilder('cita')
    .where('cita.fecha >= :inicioSemana', { inicioSemana })
    .andWhere('cita.fecha <= :finSemana', { finSemana })
    .andWhere('cita.flg_activo = 1')
    .andWhere('cita.motivo_id != 7'); // ❌ EXCLUIR reuniones clínicas

  if (terapeutaId) {
    querySemana.andWhere('cita.doctor_id = :terapeutaId', { terapeutaId });
  }

  const citasEstaSemana = await querySemana.getCount();

  // ===================================================================
  // LOGS FINALES
  // ===================================================================
  console.log(`✅ Estadísticas calculadas:`);
  console.log(`   📅 Año ${anioBase}: ${totalCitasAnio} citas (sin RC)`);
  console.log(`   📅 Mes (${mesDesde} - ${mesHasta}): ${totalCitasMes} citas (sin RC)`);
  console.log(`   📋 Reuniones Clínicas del Mes: ${totalReunionesClinicasMes}`);
  console.log(`   📅 Semana (${inicioSemana} - ${finSemana}): ${citasEstaSemana} citas (sin RC)`);

  return {
    // Totales principales (SIN reuniones clínicas)
    totalCitasAnio,
    totalCitasMes,
    citasEstaSemana,
    
    // ✅ Contador separado de reuniones clínicas
    totalReunionesClinicasMes,
    
    // Información de la semana
    inicioSemana,
    finSemana,
    
    // Información del mes usado
    mesDesde,
    mesHasta,
    
    // Metadatos
    anioBase,
    esModoCalendario,
    terapeutaId: terapeutaId || null,
  };
}

}