import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseInterceptors,
  UploadedFile,
  Res,
  Query,
  HttpStatus,
  HttpException,
  UseFilters,
  UseGuards,
  Req,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { Response, Request } from 'express';
import { ArchivosDigitalesService } from './archivos-digitales.service';
import { CreateArchivoDigitalDto } from './dto/create-archivo-digital.dto';
import { UpdateArchivoDigitalDto } from './dto/update-archivo-digital.dto';
import { Auditable } from 'src/auditoria/decorators/auditable.decorator';
import { JwtAuthGuard } from 'src/auth/guards/jwt-auth.guard';
import { Public } from 'src/auth/decorators/public.decorator';
import { AuditoriaService } from 'src/auditoria/auditoria.service';

import * as fs from 'fs';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';

 
function sanitizeFilename(filename: string): string {
  if (!filename) return 'archivo';
  
  try {
    let normalized = filename;
    
    // 1. Normalizar a NFC (forma compuesta correcta de tildes)
    normalized = normalized.normalize('NFC');
    
    // 2. Remover caracteres de control
    normalized = normalized.replace(/[\x00-\x1F\x7F]/g, '');
    
    // 3. Convertir espacios a guiones bajos
    normalized = normalized.replace(/\s+/g, '_');
    
    // 4. Permitir solo: letras (incluidas con tildes), números, puntos, guiones
    // Esto permite: a-z, A-Z, 0-9, áéíóúñÁÉÍÓÚÑüÜ, ., -, _
    normalized = normalized.replace(/[^a-zA-Z0-9áéíóúñÁÉÍÓÚÑüÜ._-]/g, '_');
    
    // 5. Limpiar múltiples guiones bajos
    normalized = normalized
      .replace(/_+/g, '_')
      .replace(/^_+|_+$/g, '');
    
    // 6. Fallback si quedó vacío
    return normalized.length > 0 ? normalized : 'archivo';
    
  } catch (error) {
    console.error('Error en sanitizeFilename:', error);
    return 'archivo';
  }
}
@Controller('backend_api/archivos-digitales')
@UseGuards(JwtAuthGuard)
export class ArchivosDigitalesController {
  constructor(
    private readonly archivosDigitalesService: ArchivosDigitalesService,
    private readonly auditoriaService: AuditoriaService,
  ) {}

  @Post()
  @Auditable({
    modulo: 'ARCHIVOS_DIGITALES',
    accion: 'SUBIR_ARCHIVO',
  })
  @UseInterceptors(FileInterceptor('archivo', {
    storage: undefined,
    fileFilter: (req, file, callback) => {
      // ✅ SANITIZAR EL NOMBRE AQUÍ MISMO, ANTES DE VALIDAR
      console.log('🔍 Nombre recibido por Multer:', file.originalname);
      console.log('🔍 Bytes originales:', Buffer.from(file.originalname, 'latin1').toString('hex'));
      
      // Intentar reinterpretar el encoding
      try {
        // Convertir de latin1 a UTF-8 correctamente
        const buffer = Buffer.from(file.originalname, 'latin1');
        const utf8Name = buffer.toString('utf8');
        console.log('🔄 Reinterpretado UTF-8:', utf8Name);
        
        // Sanitizar
        file.originalname = sanitizeFilename(utf8Name);
        console.log('✅ Nombre sanitizado:', file.originalname);
      } catch (error) {
        console.error('❌ Error al reinterpretar:', error);
        // Si falla, sanitizar directamente
        file.originalname = sanitizeFilename(file.originalname);
        console.log('✅ Nombre sanitizado (fallback):', file.originalname);
      }
      
      // Validar tipo de archivo
      const allowedMimeTypes = [
        'application/pdf',
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/gif',
        'image/bmp',
        'image/webp',
        'image/svg+xml',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'text/plain',
        'text/csv'
      ];

      if (allowedMimeTypes.includes(file.mimetype)) {
        callback(null, true);
      } else {
        callback(new HttpException(
          `Formato de archivo no permitido. Formato recibido: ${file.mimetype}`,
          HttpStatus.BAD_REQUEST
        ), false);
      }
    },
    limits: {
      fileSize: 10 * 1024 * 1024,
    },
  }))
  async create(
    @UploadedFile() file: Express.Multer.File,
    @Body() createArchivoDigitalDto: any,
  ) {
    if (!file) {
      throw new HttpException('Archivo requerido', HttpStatus.BAD_REQUEST);
    }

    const maxSize = 10 * 1024 * 1024;
    if (file.size > maxSize) {
      throw new HttpException(
        `El archivo excede el peso máximo permitido. Peso máximo: 10MB`,
        HttpStatus.BAD_REQUEST
      );
    }

    // ✅ El nombre YA viene sanitizado del fileFilter
    const nombreOriginalSanitizado = file.originalname;
    
    console.log('📄 Nombre a guardar en BD:', nombreOriginalSanitizado);
    
    const extension = path.extname(nombreOriginalSanitizado);
    const nombreSinExtension = path.basename(nombreOriginalSanitizado, extension);
    
    // Generar nombre único
    const nombreArchivo = `${uuidv4()}_${nombreSinExtension}${extension}`;
    
    const subcarpeta = 'archivos_digitales';
    const rutaArchivo = `${subcarpeta}/${nombreArchivo}`;

    const uploadsDir = path.join(process.cwd(), 'uploads');
    const subcarpetaCompleta = path.join(uploadsDir, subcarpeta);
    
    if (!fs.existsSync(subcarpetaCompleta)) {
      fs.mkdirSync(subcarpetaCompleta, { recursive: true });
    }

    const rutaCompleta = path.join(uploadsDir, rutaArchivo);
    
    try {
      fs.writeFileSync(rutaCompleta, file.buffer);
      console.log('💾 Archivo guardado:', rutaCompleta);
    } catch (error) {
      throw new HttpException(
        `Error al guardar el archivo: ${error.message}`,
        HttpStatus.INTERNAL_SERVER_ERROR
      );
    }

    const terapeutaId = parseInt(createArchivoDigitalDto.terapeutaId);
    const tipoArchivoId = parseInt(createArchivoDigitalDto.tipoArchivoId);
    const pacienteId = createArchivoDigitalDto.pacienteId ? parseInt(createArchivoDigitalDto.pacienteId) : null;

    if (isNaN(terapeutaId)) {
      throw new HttpException('ID de terapeuta inválido', HttpStatus.BAD_REQUEST);
    }

    if (isNaN(tipoArchivoId)) {
      throw new HttpException('ID de tipo de archivo inválido', HttpStatus.BAD_REQUEST);
    }

    if (pacienteId !== null && isNaN(pacienteId)) {
      throw new HttpException('ID de paciente inválido', HttpStatus.BAD_REQUEST);
    }

    const dto: CreateArchivoDigitalDto = {
      terapeutaId,
      tipoArchivoId,
      descripcion: createArchivoDigitalDto.descripcion || null,
      nombreArchivo: nombreArchivo,
      nombreOriginal: nombreOriginalSanitizado,
      tipoMime: file.mimetype,
      tamano: file.size,
      rutaArchivo: rutaArchivo,
      pacienteId,
    };

    return await this.archivosDigitalesService.create(dto);
  }

  // Ruta para obtener todos los tipos de archivo (DEBE IR ANTES que las rutas con :id)
  @Get('tipos')
  
  async findAllTiposArchivo() {
    return await this.archivosDigitalesService.findAllTiposArchivo();
  }

  @Get()
  
  async findAll(
    @Query('pacienteId') pacienteId?: string,
    @Query('terapeutaId') terapeutaId?: string,
    @Req() req?: any
  ) {
    let archivos;

    // Obtener información del usuario autenticado
    const trabajadorId = req?.user?.id;
    const rolTrabajador = req?.user?.rol?.nombre || req?.user?.rol; // Obtener el nombre del rol
    const esJefe = req?.user?.cargo?.es_jefe === true; // Jefa terapeuta ve todos los archivos

    // Si se proporcionan ambos parámetros, buscar por terapeuta Y paciente
    if (pacienteId && terapeutaId && !isNaN(parseInt(pacienteId)) && !isNaN(parseInt(terapeutaId))) {
      archivos = await this.archivosDigitalesService.findByTerapeutaAndPaciente(parseInt(terapeutaId), parseInt(pacienteId));
    }
    // Si solo se proporciona pacienteId
    else if (pacienteId && !isNaN(parseInt(pacienteId))) {
      archivos = await this.archivosDigitalesService.findByPaciente(
        parseInt(pacienteId),
        trabajadorId,
        rolTrabajador,
        esJefe
      );
    }
    // Si solo se proporciona terapeutaId
    else if (terapeutaId && !isNaN(parseInt(terapeutaId))) {
      archivos = await this.archivosDigitalesService.findByTerapeuta(parseInt(terapeutaId));
    }
    // Si no se proporcionan parámetros, devolver todos
    else {
      archivos = await this.archivosDigitalesService.findAll();
    }

    // Agregar uploads/ a la ruta de cada archivo
    return archivos.map(archivo => ({
      ...archivo,
      rutaArchivo: `uploads/${archivo.rutaArchivo}`
    }));
  }

  @Get(':id')
  
  async findOne(@Param('id') id: string) {
    const numericId = parseInt(id);
    if (isNaN(numericId)) {
      throw new HttpException('ID inválido', HttpStatus.BAD_REQUEST);
    }
    const archivo = await this.archivosDigitalesService.findOne(numericId);
    
    // Agregar uploads/ a la ruta del archivo
    return {
      ...archivo,
      rutaArchivo: `uploads/${archivo.rutaArchivo}`
    };
  }

  @Get(':id/preview')
  @Public()
  async preview(@Param('id') id: string, @Res() res: Response, @Req() req: Request) {
    const numericId = parseInt(id);
    if (isNaN(numericId)) {
      throw new HttpException('ID inválido', HttpStatus.BAD_REQUEST);
    }
    const archivoDigital = await this.archivosDigitalesService.findOne(numericId);

    // Registrar auditoría manualmente ANTES de enviar el archivo
    const user = req['user'];
    if (user && archivoDigital.paciente) {
      const userCompleto = await this.auditoriaService.completarDatosUsuario(user);
      const nombrePaciente = archivoDigital.paciente.nombres && archivoDigital.paciente.apellido_paterno
        ? `${archivoDigital.paciente.nombres} ${archivoDigital.paciente.apellido_paterno} ${archivoDigital.paciente.apellido_materno || ''}`.trim()
        : 'Sin nombre';

      await this.auditoriaService.registrar({
        trabajadorId: userCompleto.id,

        accion: 'ABRIR_ARCHIVO',
        modulo: 'ARCHIVOS_DIGITALES',
      
     

        descripcion: `Abrió archivo digital del paciente ${nombrePaciente}`,

        datosNuevos: { archivoId: archivoDigital.id, nombreArchivo: archivoDigital.nombreOriginal },
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
  
      });
    }

    const rutaCompleta = path.join(process.cwd(), 'uploads', archivoDigital.rutaArchivo);

    if (!fs.existsSync(rutaCompleta)) {
      throw new HttpException('Archivo no encontrado en el servidor', HttpStatus.NOT_FOUND);
    }

    // Headers para visualización (inline en lugar de attachment)
    res.setHeader('Content-Type', archivoDigital.tipoMime);
    res.setHeader('Content-Disposition', `inline; filename="${archivoDigital.nombreOriginal}"`);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    const fileStream = fs.createReadStream(rutaCompleta);
    fileStream.pipe(res);
  }

  @Get(':id/download')
  
  async download(@Param('id') id: string, @Res() res: Response, @Req() req: Request) {
    const numericId = parseInt(id);
    if (isNaN(numericId)) {
      throw new HttpException('ID inválido', HttpStatus.BAD_REQUEST);
    }
    const archivoDigital = await this.archivosDigitalesService.findOne(numericId);

    // Registrar auditoría manualmente ANTES de enviar el archivo
    const user = req['user'];
    if (user && archivoDigital.paciente) {
      const userCompleto = await this.auditoriaService.completarDatosUsuario(user);
      const nombrePaciente = archivoDigital.paciente.nombres && archivoDigital.paciente.apellido_paterno
        ? `${archivoDigital.paciente.nombres} ${archivoDigital.paciente.apellido_paterno} ${archivoDigital.paciente.apellido_materno || ''}`.trim()
        : 'Sin nombre';

      await this.auditoriaService.registrar({
        trabajadorId: userCompleto.id,
      

        accion: 'DESCARGAR_ARCHIVO',
        modulo: 'ARCHIVOS_DIGITALES',

      
        descripcion: `Descargó archivo digital del paciente ${nombrePaciente}`,
     
        datosNuevos: { archivoId: archivoDigital.id, nombreArchivo: archivoDigital.nombreOriginal },
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      
  

      });
    }

    const rutaCompleta = path.join(process.cwd(), 'uploads', archivoDigital.rutaArchivo);

    if (!fs.existsSync(rutaCompleta)) {
      throw new HttpException('Archivo no encontrado en el servidor', HttpStatus.NOT_FOUND);
    }

    // Headers para descarga (attachment)
    res.setHeader('Content-Type', archivoDigital.tipoMime);
    res.setHeader('Content-Disposition', `attachment; filename="${archivoDigital.nombreOriginal}"`);
    res.setHeader('Access-Control-Allow-Origin', '*');

    const fileStream = fs.createReadStream(rutaCompleta);
    fileStream.pipe(res);
  }

  @Patch(':id')
  
  async update(@Param('id') id: string, @Body() updateArchivoDigitalDto: UpdateArchivoDigitalDto) {
    const numericId = parseInt(id);
    if (isNaN(numericId)) {
      throw new HttpException('ID inválido', HttpStatus.BAD_REQUEST);
    }
    return await this.archivosDigitalesService.update(numericId, updateArchivoDigitalDto);
  }

  @Delete(':id')
  
  @Auditable({
    modulo: 'ARCHIVOS_DIGITALES',
    accion: 'ELIMINAR_ARCHIVO',
  })
  async remove(@Param('id') id: string, @Req() req: any) {
    const numericId = parseInt(id);
    if (isNaN(numericId)) {
      throw new HttpException('ID inválido', HttpStatus.BAD_REQUEST);
    }

    // Obtener información del usuario autenticado
    const trabajadorId = req?.user?.id;
    const rolTrabajador = req?.user?.rol?.nombre || req?.user?.rol;

    // Obtener el archivo para verificar quién lo subió
    const archivo = await this.archivosDigitalesService.findOne(numericId);

    // REGLAS DE PERMISOS:
    // 1. ADMIN/ADMINISTRADOR: Puede eliminar cualquier archivo
    const esAdmin = rolTrabajador && ['admin', 'administrador'].includes(rolTrabajador.toLowerCase());

    if (esAdmin) {
      // Administrador puede eliminar todo
      return await this.archivosDigitalesService.remove(numericId);
    }

    // 2. ADMISIÓN: NO puede eliminar NINGÚN archivo (ni los propios)
    const esAdmision = rolTrabajador && ['admision', 'admisión'].includes(rolTrabajador.toLowerCase());

    if (esAdmision) {
      throw new HttpException(
        'El rol de Admisión no tiene permisos para eliminar archivos. Solo el Administrador puede eliminar archivos.',
        HttpStatus.FORBIDDEN
      );
    }

    // 3. TERAPEUTA: Solo puede eliminar archivos que él mismo subió
    const esTerapeuta = rolTrabajador && rolTrabajador.toLowerCase() === 'terapeuta';

    if (esTerapeuta) {
      // Verificar si el archivo fue subido por este terapeuta
      if (archivo.terapeuta.id !== trabajadorId) {
        throw new HttpException(
          'No tienes permisos para eliminar este archivo. Solo puedes eliminar archivos que tú mismo has subido.',
          HttpStatus.FORBIDDEN
        );
      }
      // Si llegó aquí, el terapeuta está eliminando su propio archivo
      return await this.archivosDigitalesService.remove(numericId);
    }

    // Si no es ninguno de los roles esperados, denegar por defecto
    throw new HttpException(
      'No tienes permisos para eliminar archivos.',
      HttpStatus.FORBIDDEN
    );
  }
}
