import { IsNotEmpty, IsInt, IsString, IsOptional, IsDateString } from 'class-validator';

export class CreateEntrevistaAdultosDto {
  @IsNotEmpty()
  @IsInt()
  pacienteId: number;

  @IsNotEmpty()
  @IsInt()
  usuarioId: number;

  @IsNotEmpty()
  @IsDateString()
  fecha: string;

  // i. DATOS GENERALES
  @IsOptional()
  @IsString()
  estadoCivil?: string;

  @IsOptional()
  @IsString()
  religion?: string;

  @IsOptional()
  @IsString()
  escolaridad?: string;

  @IsOptional()
  @IsString()
  ocupacion?: string;

  @IsOptional()
  @IsString()
  remitidoPor?: string;

  // ii. MOTIVO DE CONSULTA
  @IsOptional()
  @IsString()
  motivoConsulta?: string;

  // iii. ANTECEDENTES DE LA SITUACIÓN
  @IsOptional()
  @IsString()
  antecedentesSituacion?: string;

  @IsOptional()
  @IsString()
  funcionesOrganicas?: string;

  // iv. HISTORIA FAMILIAR - PADRE
  @IsOptional()
  @IsString()
  nombrePadre?: string;

  @IsOptional()
  @IsString()
  edadPadre?: string;

  @IsOptional()
  @IsString()
  escolaridadOcupacionPadre?: string;

  @IsOptional()
  @IsString()
  enfermedadesPadre?: string;

  @IsOptional()
  @IsString()
  relacionPadrePaciente?: string;

  @IsOptional()
  @IsString()
  imposicionCastigosPadre?: string;

  // iv. HISTORIA FAMILIAR - MADRE
  @IsOptional()
  @IsString()
  nombreMadre?: string;

  @IsOptional()
  @IsString()
  edadMadre?: string;

  @IsOptional()
  @IsString()
  escolaridadOcupacionMadre?: string;

  @IsOptional()
  @IsString()
  enfermedadesMadre?: string;

  @IsOptional()
  @IsString()
  relacionMadrePaciente?: string;

  @IsOptional()
  @IsString()
  imposicionCastigosMadre?: string;

  // iv. HISTORIA FAMILIAR - HERMANOS Y ANTECEDENTES
  @IsOptional()
  @IsString()
  relacionHermanos?: string;

  @IsOptional()
  @IsString()
  antecedentesMedicosPsiquiatricosFamilia?: string;

  // v. SÍNTOMAS NEURÓTICOS
  @IsOptional()
  @IsString()
  pesadillas?: string;

  @IsOptional()
  @IsString()
  terrorNocturno?: string;

  @IsOptional()
  @IsString()
  sonambulismo?: string;

  @IsOptional()
  @IsString()
  enuresis?: string;

  @IsOptional()
  @IsString()
  onicofagia?: string;

  @IsOptional()
  @IsString()
  obsesionesCompulsiones?: string;

  @IsOptional()
  @IsString()
  fobias?: string;

  @IsOptional()
  @IsString()
  inquietud?: string;

  @IsOptional()
  @IsString()
  miedoEstarSolo?: string;

  // vi. SALUD FÍSICA
  @IsOptional()
  @IsString()
  infecciones?: string;

  @IsOptional()
  @IsString()
  cefalea?: string;

  @IsOptional()
  @IsString()
  convulsiones?: string;

  @IsOptional()
  @IsString()
  enfermedadesRespiratorias?: string;

  @IsOptional()
  @IsString()
  intervencionesQuirurgicas?: string;

  // vii. SOCIALIZACIÓN
  @IsOptional()
  @IsString()
  socializacion?: string;

  @IsOptional()
  @IsString()
  conductaUniversidadTrabajo?: string;

  @IsOptional()
  @IsString()
  ocupacionActualDetalles?: string;

  // viii. ANTECEDENTES PERSONALES
  @IsOptional()
  @IsString()
  circunstanciaEmbarazo?: string;

  @IsOptional()
  @IsString()
  planificadoReaccionPadres?: string;

  @IsOptional()
  @IsString()
  tipoParto?: string;

  @IsOptional()
  @IsString()
  recienNacido?: string;

  @IsOptional()
  @IsString()
  lactancia?: string;

  @IsOptional()
  @IsString()
  desarrolloMotor?: string;

  @IsOptional()
  @IsString()
  controlEsfinteres?: string;

  @IsOptional()
  @IsString()
  informacionSexualAdquirida?: string;

  @IsOptional()
  @IsString()
  enfermedadesVenereas?: string;

  @IsOptional()
  @IsString()
  periodoMenstrual?: string;

  @IsOptional()
  @IsString()
  sintomasMenstruacion?: string;

  // ix. HISTORIAL SEXUAL
  @IsOptional()
  @IsString()
  opinionNoviazgoMatrimonio?: string;

  @IsOptional()
  @IsString()
  experienciasNoviazgoMatrimonio?: string;

  // x. HÁBITOS Y ASPECTOS JUDICIALES
  @IsOptional()
  @IsString()
  alcohol?: string;

  @IsOptional()
  @IsString()
  tabaco?: string;

  @IsOptional()
  @IsString()
  drogas?: string;

  @IsOptional()
  @IsString()
  acusadoDetenidoPreso?: string;

  // xi. PERSONALIDAD PREVIA
  @IsOptional()
  @IsString()
  seguridadSiMismo?: string;

  @IsOptional()
  @IsString()
  tomaDecisiones?: string;

  @IsOptional()
  @IsString()
  miedoAbandono?: string;

  @IsOptional()
  @IsString()
  confianzaOtros?: string;

  @IsOptional()
  @IsString()
  actosImpulsivos?: string;

  @IsOptional()
  @IsString()
  preocupacionRechazoCritica?: string;

  @IsOptional()
  @IsString()
  preocupacionFracaso?: string;

  @IsOptional()
  @IsString()
  gustoSerAtractivo?: string;

  // xii. OBJETIVOS TERAPÉUTICOS INICIALES
  @IsOptional()
  @IsString()
  objetivosTerapeuticos?: string;

  // xiii. OBSERVACIONES GENERALES Y RECOMENDACIONES
  @IsOptional()
  @IsString()
  observacionesRecomendaciones?: string;
}
