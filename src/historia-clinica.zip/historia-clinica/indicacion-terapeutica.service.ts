import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { IndicacionTerapeutica } from './entities/indicacion-terapeutica.entity';
import { IndicacionCita } from './entities/indicacion-cita.entity';
import { IndicacionReferencia } from './entities/indicacion-referencia.entity';
import { IndicacionRecomendaciones } from './entities/indicacion-recomendaciones.entity';
import { IndicacionMateriales } from './entities/indicacion-materiales.entity';
import { CreateIndicacionTerapeuticaDto } from './dto/create-indicacion-terapeutica.dto';

@Injectable()
export class IndicacionTerapeuticaService {
  constructor(
    @InjectRepository(IndicacionTerapeutica)
    private readonly indicacionRepo: Repository<IndicacionTerapeutica>,
    @InjectRepository(IndicacionCita)
    private readonly citaRepo: Repository<IndicacionCita>,
    @InjectRepository(IndicacionReferencia)
    private readonly referenciaRepo: Repository<IndicacionReferencia>,
    @InjectRepository(IndicacionRecomendaciones)
    private readonly recomendacionesRepo: Repository<IndicacionRecomendaciones>,
    @InjectRepository(IndicacionMateriales)
    private readonly materialesRepo: Repository<IndicacionMateriales>,
  ) {}

  async create(dto: CreateIndicacionTerapeuticaDto): Promise<IndicacionTerapeutica> {
    const now = new Date();
    const hora = now.toTimeString().split(' ')[0];

    const indicacion = this.indicacionRepo.create({
      fecha: dto.fecha,
      hora,
      pacienteId: dto.pacienteId,
      trabajadorId: dto.trabajadorId,
      especialidadId: dto.especialidadId,
      servicioId: dto.servicioId,
    });

    const savedIndicacion = await this.indicacionRepo.save(indicacion);

    if (dto.citas && dto.citas.length > 0) {
      const citas = dto.citas.map(citaDto =>
        this.citaRepo.create({ ...citaDto, indicacionId: savedIndicacion.id })
      );
      await this.citaRepo.save(citas);
    }

    if (dto.referencias) {
      await this.referenciaRepo.save(
        this.referenciaRepo.create({ ...dto.referencias, indicacionId: savedIndicacion.id })
      );
    }

    if (dto.recomendaciones) {
      await this.recomendacionesRepo.save(
        this.recomendacionesRepo.create({ ...dto.recomendaciones, indicacionId: savedIndicacion.id })
      );
    }

    if (dto.materiales) {
      await this.materialesRepo.save(
        this.materialesRepo.create({ ...dto.materiales, indicacionId: savedIndicacion.id })
      );
    }

    return this.findOne(savedIndicacion.id);
  }

  async findByPaciente(pacienteId: number): Promise<IndicacionTerapeutica[]> {
    return this.indicacionRepo.find({
      where: { pacienteId, activo: true },
      relations: [
        'paciente', 'trabajador', 'especialidad', 'servicio',
        'citas', 'citas.tipo', 'citas.modalidad', 'citas.frecuencia',
        'referencias', 'recomendaciones', 'materiales',
      ],
      order: { fecha: 'DESC', hora: 'DESC' },
    });
  }

  async findOne(id: number): Promise<IndicacionTerapeutica> {
    const indicacion = await this.indicacionRepo.findOne({
      where: { id, activo: true },
      relations: [
        'paciente', 'trabajador', 'especialidad', 'servicio',
        'citas', 'citas.tipo', 'citas.modalidad', 'citas.frecuencia',
        'referencias', 'recomendaciones', 'materiales',
      ],
    });

    if (!indicacion) {
      throw new NotFoundException(`Indicación terapéutica con ID ${id} no encontrada`);
    }

    return indicacion;
  }

  async delete(id: number): Promise<void> {
    const indicacion = await this.findOne(id);
    indicacion.activo = false;
    await this.indicacionRepo.save(indicacion);
  }
}
