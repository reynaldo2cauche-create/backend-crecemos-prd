import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToMany
} from 'typeorm';
import { ReglaSorteo } from './regla-sorteo.entity';
import { SorteoGanador } from './sorteo-ganador.entity';

@Entity('sorteos')
export class Sorteo {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 150 })
  nombre: string;

  @Column({ type: 'varchar', length: 255, nullable: true })
  descripcion: string;

  @Column({ type: 'date', name: 'fecha_inicio' })
  fechaInicio: Date;

  @Column({ type: 'date', name: 'fecha_fin' })
  fechaFin: Date;

  @Column({ type: 'datetime', name: 'fecha_sorteo' })
  fechaSorteo: Date;

  @Column({ type: 'int', name: 'cantidad_ganadores' })
  cantidadGanadores: number;

  @OneToMany(() => ReglaSorteo, regla => regla.sorteo)
  reglas: ReglaSorteo[];

  @OneToMany(() => SorteoGanador, ganador => ganador.sorteo)
  ganadores: SorteoGanador[];

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updatedAt: Date;
}
