import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  Query,
  Res,
  UseGuards,
} from '@nestjs/common';
import { Response } from 'express';
import { SorteoService } from './sorteo.service';
import { CrearSorteoDto, RealizarSorteoDto } from './dto/crear-sorteo.dto';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { Roles } from '../auth/roles.decorator';
import { RolesGuard } from '../auth/roles.guard';

@Controller('backend_api/sorteos')
@UseGuards(JwtAuthGuard, RolesGuard)
export class SorteoController {
  constructor(private readonly sorteoService: SorteoService) {}

  // ========== STATIC ROUTES (HIGH PRIORITY) ==========

  /**
   * 📦 GET /sorteos/paquetes
   * Obtiene todos los paquetes activos
   */
  @Get('paquetes')
  @UseGuards(JwtAuthGuard)
  async obtenerPaquetes() {
    return this.sorteoService.obtenerPaquetes();
  }

  /**
   * 📋 GET /sorteos/tipos-compra
   * Obtiene todos los tipos de compra
   */
  @Get('tipos-compra')
  @UseGuards(JwtAuthGuard)
  async obtenerTiposCompra() {
    return this.sorteoService.obtenerTiposCompra();
  }

  /**
   * 📚 GET /sorteos/historial
   * Obtiene historial de sorteos con paginación
   */
  @Get('historial')
  @Roles('Administrador', 'Admision')
  async obtenerHistorial(
    @Query('page') page = 1,
    @Query('limit') limit = 10,
  ) {
    return this.sorteoService.obtenerHistorial(+page, +limit);
  }


    @Post('pacientes-elegibles')
    @Roles('Administrador', 'Admision')
    async calcularPacientesElegibles(@Body() dto: {
      fecha_inicio: string;
      fecha_fin: string;
      reglas: Array<{
        tipo_compra_id: number;
        paquete_id?: number;
        opciones_por_unidad: number;
      }>;
    }) {
      return this.sorteoService.calcularPacientesElegibles(dto);
      
    }
  /**
   * 📝 POST /sorteos/crear
   * Crea un sorteo CON reglas (sin ganadores aún)
   */
  @Post()
  @Roles('Administrador', 'Admision')
  async crearSorteo(@Body() dto: CrearSorteoDto) {
    return this.sorteoService.crearSorteo(dto);
  }

  /**
   * 🎲 POST /sorteos/realizar
   * Crea sorteo Y guarda ganadores
   */
  @Post('realizar')
  @Roles('Administrador', 'Admision')
  async realizarSorteo(@Body() dto: RealizarSorteoDto) {
    return this.sorteoService.realizarSorteo(dto);
  }

  // ========== PARAMETERIZED ROUTES (LOW PRIORITY) ==========

  /**
   * 🎯 GET /sorteos/:id/pacientes-elegibles
   * Obtiene pacientes elegibles según las reglas del sorteo
   */
  @Get(':id/pacientes-elegibles')
  @Roles('Administrador', 'Admision')
  async obtenerPacientesElegibles(@Param('id') id: number) {
    return this.sorteoService.obtenerPacientesElegibles(id);
  }

  /**
   * 📄 GET /sorteos/:id/pdf
   * Genera PDF de resultados del sorteo
   */
  @Get(':id/pdf')
  @Roles('Administrador', 'Admision')
  async generarPDF(@Param('id') id: number, @Res() res: Response) {
    const buffer = await this.sorteoService.generarPDF(id);

    res.set({
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename=sorteo_${id}.pdf`,
      'Content-Length': buffer.length,
    });

    res.send(buffer);
  }

  /**
   * 🔍 GET /sorteos/:id
   * Obtiene detalle de un sorteo específico
   */
  @Get(':id')
  @Roles('Administrador', 'Admision')
  async obtenerDetalle(@Param('id') id: number) {
    return this.sorteoService.obtenerDetalle(id);
  }

  /**
   * 🗑️ DELETE /sorteos/:id
   * Elimina un sorteo
   */
  @Delete(':id')
  @Roles('Administrador')
  async eliminar(@Param('id') id: number) {
    return this.sorteoService.eliminar(id);
  }
}