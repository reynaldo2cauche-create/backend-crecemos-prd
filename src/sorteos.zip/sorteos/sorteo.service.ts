import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Between, In, Not } from 'typeorm';
import { Sorteo } from './entities/sorteo.entity';
import { ReglaSorteo } from './entities/regla-sorteo.entity';
import { SorteoGanador } from './entities/sorteo-ganador.entity';
import { Compra } from './entities/compra.entity';
import { Paciente } from '../pacientes/paciente.entity';
import { TipoCompra } from './entities/tipo-compra.entity';
import { Paquete } from './entities/paquete.entity';
import { CrearSorteoDto, RealizarSorteoDto } from './dto/crear-sorteo.dto';
import * as PDFDocument from 'pdfkit';
import { PacienteElegibleDto } from './dto/paciente-elegible.dto';

interface PacienteElegible {
  id: number;
  nombres: string;
  apellido_paterno: string;
  apellido_materno: string;
  numero_documento: string;
  celular: string;
  correo: string;
  opciones: number; // Cuántas veces entra en el sorteo
}

@Injectable()
export class SorteoService {
  constructor(
    @InjectRepository(Sorteo)
    private sorteoRepository: Repository<Sorteo>,
    @InjectRepository(ReglaSorteo)
    private reglaRepository: Repository<ReglaSorteo>,
    @InjectRepository(SorteoGanador)
    private ganadorRepository: Repository<SorteoGanador>,
    @InjectRepository(Compra)
    private compraRepository: Repository<Compra>,
    @InjectRepository(Paciente)
    private pacienteRepository: Repository<Paciente>,
    @InjectRepository(TipoCompra)
    private tipoCompraRepository: Repository<TipoCompra>,
    @InjectRepository(Paquete)
    private paqueteRepository: Repository<Paquete>,
  ) {}

  /**
   * 🎯 Obtiene pacientes elegibles según las reglas del sorteo
   *
   * Lógica de negocio:
   * 1. Pagó dentro del mes del evento → PARTICIPA
   * 2. Pagó fin de mes anterior + usa sesiones en mes del evento → PARTICIPA
   * 3. Individual: Se agrupa a 1 entrada por paciente por mes
   * 4. Paquetes: Según opciones_por_unidad en reglas_sorteo
   */
  /**
   * 🎯 Obtiene pacientes elegibles según las reglas del sorteo
   */
  async obtenerPacientesElegibles(sorteoId: number): Promise<PacienteElegibleDto[]> {
    const sorteo = await this.sorteoRepository.findOne({
      where: { id: sorteoId },
      relations: ['reglas', 'reglas.tipoCompra', 'reglas.paquete'],
    });

    if (!sorteo) {
      throw new NotFoundException(`Sorteo con ID ${sorteoId} no encontrado`);
    }

    if (!sorteo.reglas || sorteo.reglas.length === 0) {
      throw new BadRequestException('El sorteo no tiene reglas configuradas');
    }

    const ganadoresPrevios = await this.ganadorRepository.find({
      select: ['pacienteId'],
    });
    const idsExcluidos = ganadoresPrevios.map(g => g.pacienteId);

    const fechaInicio = new Date(sorteo.fechaInicio);
    const fechaFin = new Date(sorteo.fechaFin);

    const mesAnterior = new Date(fechaInicio);
    mesAnterior.setMonth(mesAnterior.getMonth() - 1);
    const ultimoDiaMesAnterior = new Date(mesAnterior.getFullYear(), mesAnterior.getMonth() + 1, 0);

    console.log(`📅 Rango de elegibilidad: ${ultimoDiaMesAnterior.toISOString().split('T')[0]} - ${fechaFin.toISOString().split('T')[0]}`);

    const pacientesMap = new Map<number, PacienteElegibleDto>();

    for (const regla of sorteo.reglas) {
      console.log(`🔍 Procesando regla: ${regla.tipoCompra.nombre} - ${regla.paquete?.nombre || 'Todos'}`);

      const queryBuilder = this.compraRepository
        .createQueryBuilder('compra')
        .leftJoinAndSelect('compra.paciente', 'paciente')
        .leftJoinAndSelect('compra.tipoCompra', 'tipoCompra')
        .leftJoinAndSelect('compra.paquete', 'paquete')
        .where('compra.tipoCompraId = :tipoCompraId', { tipoCompraId: regla.tipoCompraId })
        .andWhere('compra.fechaCompra BETWEEN :inicio AND :fin', {
          inicio: ultimoDiaMesAnterior.toISOString().split('T')[0],
          fin: fechaFin.toISOString().split('T')[0],
        })
        .andWhere('paciente.estado_paciente_id != :estadoInactivo', { estadoInactivo: 5 })
        .andWhere('paciente.mostrar_en_listado = :visible', { visible: true });

      if (regla.paqueteId) {
        queryBuilder.andWhere('compra.paqueteId = :paqueteId', { paqueteId: regla.paqueteId });
      }

      if (idsExcluidos.length > 0) {
        queryBuilder.andWhere('paciente.id NOT IN (:...idsExcluidos)', { idsExcluidos });
      }

      const comprasElegibles = await queryBuilder.getMany();

      console.log(`✅ Compras elegibles encontradas: ${comprasElegibles.length}`);

      for (const compra of comprasElegibles) {
        const paciente = compra.paciente;
        const key = paciente.id;

        if (!pacientesMap.has(key)) {
          pacientesMap.set(key, {
            id: paciente.id,
            nombres: paciente.nombres,
            apellido_paterno: paciente.apellido_paterno,
            apellido_materno: paciente.apellido_materno,
            numero_documento: paciente.numero_documento,
            celular: paciente.celular,
            correo: paciente.correo,
            opciones: 0,
          });
        }

        const pacienteElegible = pacientesMap.get(key);

        if (regla.tipoCompra.nombre === 'INDIVIDUAL') {
          if (pacienteElegible.opciones === 0) {
            pacienteElegible.opciones = regla.opcionesPorUnidad;
          }
        } else {
          pacienteElegible.opciones += regla.opcionesPorUnidad * compra.cantidad;
        }
      }
    }

    const pacientesElegibles = Array.from(pacientesMap.values());

    console.log(`🎯 Total pacientes elegibles: ${pacientesElegibles.length}`);
    console.log(`📊 Total opciones en sorteo: ${pacientesElegibles.reduce((sum, p) => sum + p.opciones, 0)}`);

    return pacientesElegibles;
  }


    /**
   * Calcula pacientes elegibles a partir de reglas y fechas, SIN guardar nada en BD.
   * @param dto Objeto con fecha_inicio, fecha_fin y reglas
   * @returns Array de pacientes elegibles con sus opciones
   */
    async calcularPacientesElegibles(dto: {
      fecha_inicio: string;
      fecha_fin: string;
      reglas: Array<{
        tipo_compra_id: number;
        paquete_id?: number;
        opciones_por_unidad: number;
      }>;
    }): Promise<PacienteElegibleDto[]> {
      const { fecha_inicio, fecha_fin, reglas } = dto;

      if (!reglas || reglas.length === 0) {
        throw new BadRequestException('Debe enviar al menos una regla');
      }
    const fechaInicio = new Date(fecha_inicio);
    const fechaFin = new Date(fecha_fin);

   const inicioPeriodo = fechaInicio; // 2026-01-13
const finPeriodo = fechaFin;       // 2026-02-12

    // Excluir pacientes que ya han ganado antes (para evitar que ganen otra vez)
    const ganadoresPrevios = await this.ganadorRepository.find({ select: ['pacienteId'] });
    const idsExcluidos = ganadoresPrevios.map(g => g.pacienteId);

    const pacientesMap = new Map<number, PacienteElegibleDto>();

    for (const regla of reglas) {
      const tipoCompra = await this.tipoCompraRepository.findOne({
        where: { id: regla.tipo_compra_id }
      });
      if (!tipoCompra) continue;

      const queryBuilder = this.compraRepository
        .createQueryBuilder('compra')
        .leftJoinAndSelect('compra.paciente', 'paciente')
        .leftJoinAndSelect('compra.tipoCompra', 'tipoCompra')
        .leftJoinAndSelect('compra.paquete', 'paquete')
        .where('compra.tipoCompraId = :tipoCompraId', { tipoCompraId: regla.tipo_compra_id })
        .andWhere('compra.fechaCompra BETWEEN :inicio AND :fin', {
  inicio: inicioPeriodo.toISOString().split('T')[0],
  fin: finPeriodo.toISOString().split('T')[0],
})
        .andWhere('paciente.estado_paciente_id != :estadoInactivo', { estadoInactivo: 5 })
        .andWhere('paciente.mostrar_en_listado = :visible', { visible: true });

      if (regla.paquete_id) {
        queryBuilder.andWhere('compra.paqueteId = :paqueteId', { paqueteId: regla.paquete_id });
      }

      if (idsExcluidos.length > 0) {
        queryBuilder.andWhere('paciente.id NOT IN (:...idsExcluidos)', { idsExcluidos });
      }

      const comprasElegibles = await queryBuilder.getMany();

      for (const compra of comprasElegibles) {
        const paciente = compra.paciente;
        const key = paciente.id;

        if (!pacientesMap.has(key)) {
          pacientesMap.set(key, {
            id: paciente.id,
            nombres: paciente.nombres,
            apellido_paterno: paciente.apellido_paterno,
            apellido_materno: paciente.apellido_materno,
            numero_documento: paciente.numero_documento,
            celular: paciente.celular,
            correo: paciente.correo,
            opciones: 0,
          });
        }

        const pacienteElegible = pacientesMap.get(key);

        if (tipoCompra.nombre === 'INDIVIDUAL') {
          // Para individual, solo se asigna opciones una vez por paciente (no se suman)
          if (pacienteElegible.opciones === 0) {
            pacienteElegible.opciones = regla.opciones_por_unidad;
          }
        } else {
          // Para paquetes, se multiplica por la cantidad de paquetes comprados
          pacienteElegible.opciones += regla.opciones_por_unidad * compra.cantidad;
        }

        console.log('================================='); 
        console.log('📅 Fecha inicio del sorteo:', fecha_inicio);
        console.log('📅 Fecha fin del sorteo:', fecha_fin);
        
        console.log('🔍 Reglas recibidas:', JSON.stringify(reglas, null, 2));
        console.log('🚫 IDs excluidos (ganadores previos):', idsExcluidos);
        console.log('=================================');
      }
    }
    console.log('📊 Pacientes elegibles encontrados:');
    pacientesMap.forEach((p, id) => {
      console.log(`   - ID: ${id}, Nombre: ${p.nombres} ${p.apellido_paterno}, Opciones: ${p.opciones}`);
    });
    return Array.from(pacientesMap.values());
    
    
  }

  /**
   * 📝 Crear un sorteo CON reglas
   */
  async crearSorteo(dto: CrearSorteoDto) {
    // Validar que haya al menos una regla
    if (!dto.reglas || dto.reglas.length === 0) {
      throw new BadRequestException('Debe configurar al menos una regla para el sorteo');
    }

    // Crear el sorteo
    const sorteo = this.sorteoRepository.create({
      nombre: dto.nombre,
      descripcion: dto.descripcion || '',
      fechaInicio: new Date(dto.fecha_inicio),
      fechaFin: new Date(dto.fecha_fin),
      fechaSorteo: new Date(dto.fecha_sorteo),
      cantidadGanadores: dto.cantidad_ganadores,
    });

    const sorteoGuardado = await this.sorteoRepository.save(sorteo);

    // Crear las reglas
    const reglas = dto.reglas.map(r =>
      this.reglaRepository.create({
        sorteoId: sorteoGuardado.id,
        tipoCompraId: r.tipo_compra_id,
        paqueteId: r.paquete_id || null,
        opcionesPorUnidad: r.opciones_por_unidad,
      }),
    );

    await this.reglaRepository.save(reglas);

    // Retornar sorteo con reglas
    return this.sorteoRepository.findOne({
      where: { id: sorteoGuardado.id },
      relations: ['reglas', 'reglas.tipoCompra', 'reglas.paquete'],
    });
  }

  /**
   * 🎲 Realizar sorteo (guardar ganadores)
   */
  async realizarSorteo(dto: RealizarSorteoDto) {
    // Primero crear el sorteo
    const sorteo = await this.crearSorteo(dto);

    // Validar que todos los pacientes existan
    const pacienteIds = dto.ganadores.map(g => g.paciente_id);
    const pacientes = await this.pacienteRepository.findBy({
      id: In(pacienteIds),
    });

    if (pacientes.length !== pacienteIds.length) {
      throw new BadRequestException('Uno o más pacientes no existen');
    }

    // Crear ganadores
    const ganadores = dto.ganadores.map(g =>
      this.ganadorRepository.create({
        sorteoId: sorteo.id,
        pacienteId: g.paciente_id,
        posicion: g.posicion,
      }),
    );

    await this.ganadorRepository.save(ganadores);

    // Retornar sorteo completo
    return this.sorteoRepository.findOne({
      where: { id: sorteo.id },
      relations: ['reglas', 'reglas.tipoCompra', 'reglas.paquete', 'ganadores', 'ganadores.paciente'],
    });
  }

  /**
   * 📚 Obtener historial de sorteos
   */
  async obtenerHistorial(page = 1, limit = 10) {
    const [sorteos, total] = await this.sorteoRepository.findAndCount({
      relations: ['ganadores', 'reglas'],
      order: { fechaSorteo: 'DESC' },
      skip: (page - 1) * limit,
      take: limit,
    });

    return {
      data: sorteos.map(s => ({
        id: s.id,
        nombre: s.nombre,
        descripcion: s.descripcion,
        fecha_inicio: s.fechaInicio,
        fecha_fin: s.fechaFin,
        fecha_sorteo: s.fechaSorteo,
        cantidad_ganadores: s.cantidadGanadores,
        total_ganadores_registrados: s.ganadores?.length || 0,
        cantidad_reglas: s.reglas?.length || 0,
        created_at: s.createdAt,
      })),
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    };
  }

  /**
   * 🔍 Obtener detalle de un sorteo
   */
  async obtenerDetalle(id: number) {
    const sorteo = await this.sorteoRepository.findOne({
      where: { id },
      relations: [
        'ganadores',
        'ganadores.paciente',
        'reglas',
        'reglas.tipoCompra',
        'reglas.paquete',
      ],
    });

    if (!sorteo) {
      throw new NotFoundException(`Sorteo con ID ${id} no encontrado`);
    }

    return {
      id: sorteo.id,
      nombre: sorteo.nombre,
      descripcion: sorteo.descripcion,
      fecha_inicio: sorteo.fechaInicio,
      fecha_fin: sorteo.fechaFin,
      fecha_sorteo: sorteo.fechaSorteo,
      cantidad_ganadores: sorteo.cantidadGanadores,
      created_at: sorteo.createdAt,
      reglas: sorteo.reglas?.map(r => ({
        id: r.id,
        tipo_compra: r.tipoCompra?.nombre,
        paquete: r.paquete?.nombre || null,
        opciones_por_unidad: r.opcionesPorUnidad,
      })) || [],
      ganadores: sorteo.ganadores
        ?.map(g => ({
          id: g.id,
          posicion: g.posicion,
          paciente_id: g.pacienteId,
          nombres: g.paciente?.nombres,
          apellido_paterno: g.paciente?.apellido_paterno,
          apellido_materno: g.paciente?.apellido_materno,
          numero_documento: g.paciente?.numero_documento,
          celular: g.paciente?.celular,
          correo: g.paciente?.correo,
          created_at: g.createdAt,
        }))
        .sort((a, b) => a.posicion - b.posicion) || [],
    };
  }

  /**
   * 🗑️ Eliminar un sorteo
   */
  async eliminar(id: number) {
    const sorteo = await this.sorteoRepository.findOne({ where: { id } });

    if (!sorteo) {
      throw new NotFoundException(`Sorteo con ID ${id} no encontrado`);
    }

    await this.sorteoRepository.remove(sorteo);
    return { message: 'Sorteo eliminado exitosamente' };
  }

  /**
   * 📄 Generar PDF de resultados
   */
  async generarPDF(id: number): Promise<Buffer> {
    const sorteo = await this.obtenerDetalle(id);

    return new Promise((resolve, reject) => {
      const doc = new PDFDocument({ margin: 50 });
      const chunks: Buffer[] = [];

      doc.on('data', (chunk) => chunks.push(chunk));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);

      // Header
      doc
        .fontSize(20)
        .fillColor('#667eea')
        .text('Centro Crecemos', { align: 'center' })
        .moveDown(0.5);

      doc
        .fontSize(16)
        .fillColor('#000000')
        .text('Resultados del Sorteo', { align: 'center' })
        .moveDown(2);

      // Información del sorteo
      doc.fontSize(12).fillColor('#333333');
      doc.text(`Sorteo: ${sorteo.nombre}`, { continued: false });
      doc.text(`Descripción: ${sorteo.descripcion || 'Sin descripción'}`, { continued: false });
      doc.text(
        `Período: ${new Date(sorteo.fecha_inicio).toLocaleDateString('es-PE')} - ${new Date(sorteo.fecha_fin).toLocaleDateString('es-PE')}`,
        { continued: false },
      );
      doc.text(`Total de ganadores: ${sorteo.cantidad_ganadores}`, { continued: false });
      doc.moveDown(2);

      // Línea divisoria
      doc
        .moveTo(50, doc.y)
        .lineTo(550, doc.y)
        .strokeColor('#667eea')
        .lineWidth(2)
        .stroke()
        .moveDown(1);

      // Título de ganadores
      doc
        .fontSize(14)
        .fillColor('#667eea')
        .text('🏆 Ganadores del Sorteo', { underline: true })
        .moveDown(1);

      // Lista de ganadores
      sorteo.ganadores.forEach((ganador) => {
        const nombreCompleto = `${ganador.nombres} ${ganador.apellido_paterno} ${ganador.apellido_materno || ''}`.trim();

        doc.fontSize(12).fillColor('#ffd700').text(`${ganador.posicion}° Lugar`, {
          continued: true,
        });

        doc.fillColor('#000000').text(` - ${nombreCompleto}`, { continued: false });

        doc
          .fontSize(10)
          .fillColor('#666666')
          .text(`   DNI: ${ganador.numero_documento}`, { continued: false });

        if (ganador.celular) {
          doc.text(`   Teléfono: ${ganador.celular}`, { continued: false });
        }

        if (ganador.correo) {
          doc.text(`   Correo: ${ganador.correo}`, { continued: false });
        }

        doc.moveDown(1.5);
      });

      // Footer
      doc
        .moveDown(3)
        .fontSize(8)
        .fillColor('#999999')
        .text(
          `Documento generado el ${new Date().toLocaleString('es-PE')} | Centro Crecemos - www.crecemos.com.pe`,
          50,
          doc.page.height - 50,
          { align: 'center', width: 500 },
        );

      doc.end();
    });
  }

  /**
   * 📦 Obtener todos los paquetes activos
   */
  async obtenerPaquetes() {
    return this.paqueteRepository.find({
      where: { flgActivo: true },
      order: { cantidadSesiones: 'ASC' },
    });
  }

  /**
   * 📋 Obtener todos los tipos de compra
   */
  async obtenerTiposCompra() {
    return this.tipoCompraRepository.find({
      where: { flgActivo: true },
      order: { nombre: 'ASC' },
    });
  }
}
