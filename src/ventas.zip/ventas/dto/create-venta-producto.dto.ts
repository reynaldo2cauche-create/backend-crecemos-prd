import { IsNumber, IsString, IsOptional, IsArray, ValidateNested, IsPositive, Min } from 'class-validator';
import { Type } from 'class-transformer';

export class DetalleVentaProductoDto {
  @IsNumber()
  @Type(() => Number)
  producto_id: number;

  @IsNumber()
  @IsPositive()
  @Type(() => Number)
  cantidad: number;

  @IsNumber({ maxDecimalPlaces: 2 })
  @IsPositive()
  @Type(() => Number)
  precio_unitario: number;

  @IsOptional()
  @IsNumber()
  @Type(() => Number)
  descuento_tipo_id?: number;

  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Type(() => Number)
  descuento_valor?: number;
}

export class CreateVentaProductoDto {
  /** 1=Paciente, 2=Responsable, 3=Externo */
  @IsNumber()
  @Type(() => Number)
  tipo_comprador_id: number;

  @IsOptional()
  @IsNumber()
  @Type(() => Number)
  paciente_id?: number;

  @IsOptional()
  @IsNumber()
  @Type(() => Number)
  responsable_id?: number;

  @IsOptional()
  @IsNumber()
  @Type(() => Number)
  comprador_externo_id?: number;

  @IsString()
  fecha_venta: string;

  @IsOptional()
  @IsNumber()
  @Type(() => Number)
  descuento_tipo_id?: number;

  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 2 })
  @Min(0)
  @Type(() => Number)
  descuento_valor?: number;

  @IsOptional()
  @IsString()
  nota?: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => DetalleVentaProductoDto)
  detalles: DetalleVentaProductoDto[];

  @IsOptional()
  user_crea_id?: number;
}
